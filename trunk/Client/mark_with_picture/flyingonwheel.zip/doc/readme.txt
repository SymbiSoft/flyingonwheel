HOWTO:
first, you should register on http://flyingonwheel.appspot.com/(use name: demo & password: demo for test)
second, if you don't have a python platform, you need to install it(Python_1.9.7.sis & PythonScriptShell_1.9.7_3_2.sis)
third, unzip the file which I submited and copy files which under src to "e:\data\python", then run the mark.py(you should test outdoors)
	Options > Setting for set your name & password(use name: demo & password: demo for test)
	Options > Start Mark for mark your location
	Options > Exit for exit the app
forth, login http://flyingonwheel.appspot.com/ with name&password which your have registered(use name: demo & password: demo for test)

Aim:
To help users record life, which can mark the points and photo, then post to  flyingonwheel.appspot.com. You can review it later on web.
this can be recorded daily, monthly, or every year where you have been to, and attach your local infomation(landmark in the vicinity, local name, local description) to it

Requirements:
os need s60 v3 or v5
have gps function and networking
(5800xm works fine)

Attention:
As the gps hardware limitations, should be used outdoor or beside window
web: looks like web1.png web2.png
client: looks like client1.png client2.png